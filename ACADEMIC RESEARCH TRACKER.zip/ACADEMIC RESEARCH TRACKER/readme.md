# Academic Research Tracker API

> **Academic Submission Note:** This project is submitted as a zipped archive. The complete source code (`app.py` and `database.py`) is included within the submission package. No additional downloads are required to evaluate the project.

---

# Project Overview

The Academic Research Tracker API is a RESTful backend application developed using Flask and MongoDB to manage academic departments, researchers, students, and scholarly publications within a university environment.

The system demonstrates how complex relational structures can be implemented in a document-oriented database by enforcing application-level validation and entity relationships.

Unlike traditional SQL-based systems, this project uses MongoDB collections and ObjectId references to model:

* One-to-Many relationships
* Many-to-Many relationships
* Cross-collection validation
* Aggregated analytical reporting

The API operates independently of any frontend interface and communicates entirely through JSON-based requests and responses.

---

# System Architecture

The project follows a modular backend architecture:

```text
Client (Postman)
          │
          ▼
      Flask API
          │
          ▼
      MongoDB
```

The application is divided into:

* `app.py` – API routes and business logic
* `database.py` – MongoDB connection configuration
* `.env` – Environment configuration

---

# Data Model

## Departments

Departments serve as the root entity of the system.

Each department contains:

* Department Name
* Building Information

Example:

```json
{
  "name": "Computer Science",
  "building": "Block A"
}
```

---

## Staff

Staff members belong to a department through a MongoDB ObjectId reference.

Relationship:

```text
Department (1) ──────── (Many) Staff
```

Stored Fields:

* Name
* Role
* Email
* Department ID

---

## Students

Students are linked to departments using ObjectId references.

Relationship:

```text
Department (1) ──────── (Many) Students
```

Stored Fields:

* Name
* Enrollment Year
* Degree Level
* Department ID

---

## Publications

Publications represent the research output of departments.

A publication may contain:

* Multiple staff authors
* Multiple student authors

Relationship:

```text
Staff      ─┐
            ├── Publication
Students   ─┘
```

This creates a Many-to-Many relationship implemented through arrays of MongoDB ObjectIds.

Stored Fields:

* Title
* Publish Date
* Department ID
* Staff Author IDs
* Student Author IDs

---

# Key Features

## CRUD Operations

The API supports full Create, Read, Update, and Delete functionality.

### Create

* Create Departments
* Create Staff Members
* Create Students
* Create Publications

### Read

* Retrieve Individual Staff Records
* Retrieve Individual Student Records
* Retrieve Publications by Department

### Update

* Update Staff Information
* Modify Roles
* Update Email Addresses
* Reassign Departments

### Delete

* Remove Student Records

---

## Referential Integrity Validation

MongoDB does not automatically enforce foreign key constraints.

To maintain data consistency, the API verifies that referenced departments exist before allowing:

* Staff creation
* Student creation

This prevents orphaned records from being inserted into the database.

---

## Error Handling

The API implements robust validation using:

```python
bson.errors.InvalidId
```

The system safely handles:

* Invalid MongoDB IDs
* Missing records
* Missing request fields
* Malformed payloads

This prevents unexpected application crashes and improves reliability.

---

## BSON to JSON Conversion

MongoDB stores identifiers as BSON ObjectIds.

Before returning responses, the API automatically converts:

```python
ObjectId(...)
```

into standard string representations suitable for JSON serialization.

---

# Aggregation Framework Analytics Module

One of the most advanced components of this project is the Department Statistics endpoint.

```http
GET /api/departments/<dept_id>/stats
```

This endpoint uses MongoDB's Aggregation Framework to generate analytical reports.

## Department Overview Statistics

The system calculates:

* Total Publications
* Average Staff Authors per Paper
* Average Student Authors per Paper

Aggregation stages used:

* `$match`
* `$project`
* `$group`

---

## Research Impact Leaderboard

The system generates a ranked list of researchers based on publication activity.

Aggregation stages used:

* `$match`
* `$unwind`
* `$group`
* `$lookup`
* `$project`
* `$sort`

The leaderboard:

1. Counts publications per staff member
2. Joins publication data with staff records
3. Calculates an Impact Score

Formula:

```text
Impact Score = Publication Count × 10
```

This demonstrates cross-collection analytics without traditional SQL joins.

---

# Installation

## Prerequisites

Install:

* Python 3.8 or higher
* MongoDB Community Server
* Postman, Insomnia, or cURL

---

## Create Virtual Environment

```bash
python -m venv venv
```

### Windows

```bash
.\venv\Scripts\activate
```

### Linux / macOS

```bash
source venv/bin/activate
```

---

## Install Dependencies

```bash
pip install Flask pymongo python-dotenv
```

---

## Configure Environment Variables

Create a `.env` file:

```env
MONGO_URI=mongodb://localhost:27017/university_db
```

---

## Run the Application

```bash
python app.py
```

Server:

```text
http://127.0.0.1:5000
```

---

# API Endpoints

## Departments

### Create Department

```http
POST /api/departments
```

---

## Staff

### Create Staff Member

```http
POST /api/staff
```

### Retrieve Staff Member

```http
GET /api/staff/<staff_id>
```

### Update Staff Member

```http
PUT /api/staff/<staff_id>
```

---

## Students

### Create Student

```http
POST /api/students
```

### Retrieve Student

```http
GET /api/students/<student_id>
```

### Delete Student

```http
DELETE /api/students/<student_id>
```

---

## Publications

### Create Publication

```http
POST /api/publications
```

### Retrieve Publications by Department

```http
GET /api/departments/<dept_id>/publications
```

---

## Analytics

### Department Statistics Dashboard

```http
GET /api/departments/<dept_id>/stats
```

Returns:

* Publication Metrics
* Author Statistics
* Research Impact Leaderboard

---

# Technologies Used

| Technology    | Purpose                         |
| ------------- | ------------------------------- |
| Python        | Core Programming Language       |
| Flask         | REST API Development            |
| MongoDB       | NoSQL Database                  |
| PyMongo       | MongoDB Driver                  |
| python-dotenv | Environment Variable Management |

---

# Academic Concepts Demonstrated

* RESTful API Design
* MongoDB Document Modeling
* CRUD Operations
* One-to-Many Relationships
* Many-to-Many Relationships
* ObjectId Referencing
* Data Validation
* Exception Handling
* Aggregation Framework
* Cross-Collection Queries
* Backend Service Architecture
* Research Data Management Systems

---

# Conclusion

This project demonstrates how MongoDB can be used to model complex academic research ecosystems while maintaining data consistency, relational integrity, and analytical reporting capabilities. Through CRUD operations, author-publication mapping, validation mechanisms, and aggregation pipelines, the Academic Research Tracker API provides a complete backend solution for managing and analyzing scholarly research activity.
