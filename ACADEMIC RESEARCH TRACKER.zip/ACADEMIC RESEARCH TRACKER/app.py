from flask import Flask, request, jsonify
from dotenv import load_dotenv
from database import get_db
from bson.objectid import ObjectId
from bson.errors import InvalidId

load_dotenv()
app = Flask(__name__)
db = get_db()

# 1. CREATE (POST Routes)


@app.route('/api/departments', methods=['POST'])
def create_department():
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({"error": "Department name is required"}), 400
        
    new_department = {
        "name": data['name'],
        "building": data.get('building', 'Unassigned')
    }
    
    result = db.departments.insert_one(new_department)
    return jsonify({
        "message": "Department created successfully",
        "department_id": str(result.inserted_id)
    }), 201

@app.route('/api/staff', methods=['POST'])
def create_staff():
    data = request.get_json()
    if not all(k in data for k in ("name", "role", "department_id", "email")):
        return jsonify({"error": "Missing required fields"}), 400
        
    try:
        dept_id = ObjectId(data['department_id'])
    except InvalidId:
        return jsonify({"error": "Invalid department_id format"}), 400

    if not db.departments.find_one({"_id": dept_id}):
        return jsonify({"error": "Department not found"}), 404

    new_staff = {
        "name": data['name'],
        "role": data['role'],
        "department_id": dept_id,
        "email": data['email']
    }
    
    result = db.staff.insert_one(new_staff)
    return jsonify({
        "message": "Staff member added successfully",
        "staff_id": str(result.inserted_id)
    }), 201

@app.route('/api/students', methods=['POST'])
def create_student():
    data = request.get_json()
    if not all(k in data for k in ("name", "enrollment_year", "department_id", "degree_level")):
        return jsonify({"error": "Missing required fields"}), 400
        
    try:
        dept_id = ObjectId(data['department_id'])
    except InvalidId:
        return jsonify({"error": "Invalid department_id format"}), 400

    if not db.departments.find_one({"_id": dept_id}):
        return jsonify({"error": "Department not found"}), 404

    new_student = {
        "name": data['name'],
        "enrollment_year": data['enrollment_year'],
        "department_id": dept_id,
        "degree_level": data['degree_level']
    }
    
    result = db.students.insert_one(new_student)
    return jsonify({
        "message": "Student added successfully",
        "student_id": str(result.inserted_id)
    }), 201

@app.route('/api/publications', methods=['POST'])
def create_publication():
    data = request.get_json()
    if not all(k in data for k in ("title", "publish_date", "department_id", "staff_authors", "student_authors")):
        return jsonify({"error": "Missing required fields"}), 400
        
    try:
        dept_id = ObjectId(data['department_id'])
        staff_ids = [ObjectId(sid) for sid in data['staff_authors']]
        student_ids = [ObjectId(sid) for sid in data['student_authors']]
    except InvalidId:
        return jsonify({"error": "Invalid ID format in payload"}), 400

    new_publication = {
        "title": data['title'],
        "publish_date": data['publish_date'],
        "department_id": dept_id,
        "staff_authors": staff_ids,
        "student_authors": student_ids
    }
    
    result = db.publications.insert_one(new_publication)
    return jsonify({
        "message": "Publication logged successfully",
        "publication_id": str(result.inserted_id)
    }), 201

# 2. READ (GET Routes)


@app.route('/api/departments/<dept_id>/publications', methods=['GET'])
def get_department_publications(dept_id):
    try:
        target_dept = ObjectId(dept_id)
    except InvalidId:
        return jsonify({"error": "Invalid department ID"}), 400

    pubs = list(db.publications.find({"department_id": target_dept}))
    
    for pub in pubs:
        pub['_id'] = str(pub['_id'])
        pub['department_id'] = str(pub['department_id'])
        pub['staff_authors'] = [str(sid) for sid in pub['staff_authors']]
        pub['student_authors'] = [str(sid) for sid in pub['student_authors']]

    return jsonify(pubs), 200

@app.route('/api/staff/<staff_id>', methods=['GET'])
def get_staff(staff_id):
    try:
        staff = db.staff.find_one({"_id": ObjectId(staff_id)})
        if not staff:
            return jsonify({"error": "Staff not found"}), 404
            
        staff['_id'] = str(staff['_id'])
        staff['department_id'] = str(staff['department_id'])
        return jsonify(staff), 200
    except InvalidId:
        return jsonify({"error": "Invalid ID format"}), 400

@app.route('/api/students/<student_id>', methods=['GET'])
def get_student(student_id):
    try:
        student = db.students.find_one({"_id": ObjectId(student_id)})
        if not student:
            return jsonify({"error": "Student not found (Deleted)"}), 404
            
        student['_id'] = str(student['_id'])
        student['department_id'] = str(student['department_id'])
        return jsonify(student), 200
    except InvalidId:
        return jsonify({"error": "Invalid ID format"}), 400


# 3. UPDATE (PUT Route)

@app.route('/api/staff/<staff_id>', methods=['PUT'])
def update_staff(staff_id):
    data = request.get_json()
    try:
        target_id = ObjectId(staff_id)
    except InvalidId:
        return jsonify({"error": "Invalid staff ID"}), 400

    update_fields = {}
    if 'role' in data: update_fields['role'] = data['role']
    if 'email' in data: update_fields['email'] = data['email']
    if 'department_id' in data:
        try:
            update_fields['department_id'] = ObjectId(data['department_id'])
        except InvalidId:
            return jsonify({"error": "Invalid department ID"}), 400

    if not update_fields:
        return jsonify({"error": "No fields to update"}), 400

    result = db.staff.update_one({"_id": target_id}, {"$set": update_fields})
    
    if result.matched_count == 0:
        return jsonify({"error": "Staff member not found"}), 404
        
    return jsonify({"message": "Staff updated successfully"}), 200


# 4. DELETE (DELETE Route)


@app.route('/api/students/<student_id>', methods=['DELETE'])
def delete_student(student_id):
    try:
        target_id = ObjectId(student_id)
    except InvalidId:
        return jsonify({"error": "Invalid student ID"}), 400

    result = db.students.delete_one({"_id": target_id})
    
    if result.deleted_count == 0:
        return jsonify({"error": "Student not found"}), 404
        
    return jsonify({"message": "Student deleted successfully"}), 200

#5.SPECIAL AGGREGATION MODULE
@app.route('/api/departments/<dept_id>/stats', methods=['GET'])
def get_department_stats(dept_id):
    try:
        target_dept = ObjectId(dept_id)
    except InvalidId:
        return jsonify({"error": "Invalid department ID"}), 400

    # Pipeline 1: Department Averages
    dept_pipeline = [
        {"$match": {"department_id": target_dept}},
        {"$project": {
            "staff_count": {"$size": {"$ifNull": ["$staff_authors", []]}},
            "student_count": {"$size": {"$ifNull": ["$student_authors", []]}}
        }},
        {"$group": {
            "_id": None,
            "total_publications": {"$sum": 1},
            "avg_staff_per_paper": {"$avg": "$staff_count"},
            "avg_students_per_paper": {"$avg": "$student_count"}
        }}
    ]
    
    dept_stats_cursor = list(db.publications.aggregate(dept_pipeline))
    
    # Pipeline 2: Staff Impact Score Leaderboard
    leaderboard_pipeline = [
        {"$match": {"department_id": target_dept}},
        {"$unwind": "$staff_authors"}, # Break the arrays apart
        {"$group": {
            "_id": "$staff_authors",
            "publication_count": {"$sum": 1}
        }},
        {"$lookup": {                     # Join with the Staff collection
            "from": "staff",
            "localField": "_id",
            "foreignField": "_id",
            "as": "staff_info"
        }},
        {"$unwind": "$staff_info"},
        {"$project": {                    # Format the final output
            "_id": 0,
            "staff_name": "$staff_info.name",
            "role": "$staff_info.role",
            "impact_score": {"$multiply": ["$publication_count", 10]} 
        }},
        {"$sort": {"impact_score": -1}}   # Sort highest to lowest
    ]
    
    leaderboard = list(db.publications.aggregate(leaderboard_pipeline))

    if not dept_stats_cursor:
        return jsonify({"message": "No publication data available for this department"}), 404

    # Clean up the output
    stats = dept_stats_cursor[0]
    del stats['_id'] 

    return jsonify({
        "department_overview": stats,
        "top_researchers": leaderboard
    }), 200


#----------------------------------------------------------------------------------------------------------
# SERVER EXECUTION


if __name__ == '__main__':
    app.run(debug=True)