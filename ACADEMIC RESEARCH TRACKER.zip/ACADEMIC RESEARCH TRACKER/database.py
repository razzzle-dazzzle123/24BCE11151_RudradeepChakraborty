from pymongo import MongoClient
import os

def get_db():
    # Fetch the URI from the .env file
    client = MongoClient(os.getenv("MONGO_URI"))
    
    # Connect to a database named 'university_db'
    db = client.get_database("university_db") 
    return db